OC.L10N.register(
    "photos",
    {
    "Photos" : "Foto’s",
    "Favorites" : "Gunstelinge",
    "An error occurred" : "'n Fout het voorgekom"
},
"nplurals=2; plural=(n != 1);");
