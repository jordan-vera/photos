OC.L10N.register(
    "photos",
    {
    "Photos" : "Kuvat",
    "Your photos" : "Valokuvasi",
    "Favorites" : "Suosikit",
    "An error occurred" : "Tapahtui virhe"
},
"nplurals=2; plural=(n != 1);");
