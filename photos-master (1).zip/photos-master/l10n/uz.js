OC.L10N.register(
    "photos",
    {
    "Photos" : "Rasmlar"
},
"nplurals=1; plural=0;");
