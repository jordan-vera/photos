OC.L10N.register(
    "photos",
    {
    "Photos" : "Photos",
    "Favorites" : "Favorits"
},
"nplurals=2; plural=(n > 1);");
