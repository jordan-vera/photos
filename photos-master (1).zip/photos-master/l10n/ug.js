OC.L10N.register(
    "photos",
    {
    "Photos" : "Photos",
    "Favorites" : "يىغقۇچ"
},
"nplurals=1; plural=0;");
