OC.L10N.register(
    "photos",
    {
    "Photos" : "Foto",
    "Favorites" : "Favorit"
},
"nplurals=2; plural=(n != 1);");
