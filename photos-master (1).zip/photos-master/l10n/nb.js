OC.L10N.register(
    "photos",
    {
    "Photos" : "Bilder",
    "Favorites" : "Favoritter",
    "An error occurred" : "En feil oppstod"
},
"nplurals=2; plural=(n != 1);");
