OC.L10N.register(
    "photos",
    {
    "Photos" : "Photos",
    "Favorites" : "Favorites"
},
"nplurals=2; plural=(n != 1);");
