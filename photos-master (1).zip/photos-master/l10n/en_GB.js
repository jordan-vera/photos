OC.L10N.register(
    "photos",
    {
    "Photos" : "Photos",
    "Favorites" : "Favourites"
},
"nplurals=2; plural=(n != 1);");
