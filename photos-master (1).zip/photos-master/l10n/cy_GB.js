OC.L10N.register(
    "photos",
    {
    "Photos" : "Lluniau",
    "Favorites" : "Ffefrynnau",
    "An error occurred" : "Digwyddodd gwall"
},
"nplurals=4; plural=(n==1) ? 0 : (n==2) ? 1 : (n != 8 && n != 11) ? 2 : 3;");
