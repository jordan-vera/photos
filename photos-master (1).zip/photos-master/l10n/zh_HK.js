OC.L10N.register(
    "photos",
    {
    "Photos" : "相片",
    "Favorites" : "最愛"
},
"nplurals=1; plural=0;");
