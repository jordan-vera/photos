OC.L10N.register(
    "photos",
    {
    "Photos" : "Photos",
    "Favorites" : "Sevimlilər"
},
"nplurals=2; plural=(n != 1);");
