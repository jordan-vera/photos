OC.L10N.register(
    "photos",
    {
    "Photos" : "Зурагнууд",
    "Favorites" : "Онцолсон"
},
"nplurals=2; plural=(n != 1);");
