OC.L10N.register(
    "photos",
    {
    "Photos" : "Photos",
    "Favorites" : "Favoritos"
},
"nplurals=2; plural=(n != 1);");
