OC.L10N.register(
    "photos",
    {
    "Photos" : "사진",
    "Favorites" : "즐겨찾기",
    "An error occurred" : "오류가 발생함"
},
"nplurals=1; plural=0;");
