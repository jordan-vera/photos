OC.L10N.register(
    "photos",
    {
    "Photos" : "Photos",
    "Favorites" : "Favorites"
},
"nplurals=1; plural=0;");
