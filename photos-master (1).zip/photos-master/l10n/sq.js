OC.L10N.register(
    "photos",
    {
    "Photos" : "Foto",
    "Favorites" : "Favorites"
},
"nplurals=2; plural=(n != 1);");
