OC.L10N.register(
    "photos",
    {
    "Photos" : "Foto",
    "Favorites" : "Disukai"
},
"nplurals=1; plural=0;");
