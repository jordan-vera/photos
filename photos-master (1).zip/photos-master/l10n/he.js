OC.L10N.register(
    "photos",
    {
    "Photos" : "תמונות",
    "Favorites" : "מועדפים",
    "An error occurred" : "אירעה שגיאה"
},
"nplurals=4; plural=(n == 1 && n % 1 == 0) ? 0 : (n == 2 && n % 1 == 0) ? 1: (n % 10 == 0 && n % 1 == 0 && n > 10) ? 2 : 3;");
