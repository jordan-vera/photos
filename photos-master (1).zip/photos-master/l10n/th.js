OC.L10N.register(
    "photos",
    {
    "Photos" : "Photos",
    "Favorites" : "รายการโปรด"
},
"nplurals=1; plural=0;");
