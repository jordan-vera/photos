OC.L10N.register(
    "photos",
    {
    "Photos" : "Bildes",
    "Favorites" : "Favorīti",
    "An error occurred" : "Gadījās kļūda"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n != 0 ? 1 : 2);");
