OC.L10N.register(
    "photos",
    {
    "Photos" : "Ảnh",
    "Favorites" : "Ưa thích"
},
"nplurals=1; plural=0;");
