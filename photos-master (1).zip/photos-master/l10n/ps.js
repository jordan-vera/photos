OC.L10N.register(
    "photos",
    {
    "Favorites" : "په نښه شوي"
},
"nplurals=2; plural=(n != 1);");
