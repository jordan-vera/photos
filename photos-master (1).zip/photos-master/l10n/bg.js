OC.L10N.register(
    "photos",
    {
    "Photos" : "Снимки",
    "Favorites" : "Любими",
    "An error occurred" : "Възникна грешка"
},
"nplurals=2; plural=(n != 1);");
