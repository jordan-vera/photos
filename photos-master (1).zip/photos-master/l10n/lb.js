OC.L10N.register(
    "photos",
    {
    "Photos" : "Photos",
    "Favorites" : "Favoriten"
},
"nplurals=2; plural=(n != 1);");
