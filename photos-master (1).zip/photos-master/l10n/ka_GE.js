OC.L10N.register(
    "photos",
    {
    "Photos" : "ფოტოები",
    "Favorites" : "რჩეულები"
},
"nplurals=2; plural=(n!=1);");
