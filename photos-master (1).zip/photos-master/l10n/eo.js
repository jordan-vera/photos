OC.L10N.register(
    "photos",
    {
    "Photos" : "Fotoj",
    "Favorites" : "Pliŝataĵoj",
    "An error occurred" : "Eraro okazis"
},
"nplurals=2; plural=(n != 1);");
