OC.L10N.register(
    "photos",
    {
    "Photos" : "Photos",
    "Favorites" : "விருப்பங்கள்"
},
"nplurals=2; plural=(n != 1);");
