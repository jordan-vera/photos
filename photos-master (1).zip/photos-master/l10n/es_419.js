OC.L10N.register(
    "photos",
    {
    "Photos" : "Fotos",
    "Favorites" : "Favoritos"
},
"nplurals=2; plural=(n != 1);");
