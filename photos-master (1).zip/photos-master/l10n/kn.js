OC.L10N.register(
    "photos",
    {
    "Photos" : "Photos",
    "Favorites" : "ಅಚ್ಚುಮೆಚ್ಚಿನ"
},
"nplurals=2; plural=(n > 1);");
