module.exports = {
	extends: [
		'nextcloud'
	]
};
